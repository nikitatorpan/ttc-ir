const CONFIG = {
  "docs": [
    {
      "title": "Квартальный отчёт — Fund I (Demo)",
      "category": "Отчётность",
      "year": 2025,
      "quarter": "Q2",
      "url": "https://example.com/report-Q2-2025.pdf"
    },
    {
      "title": "Годовой отчёт — Fund I (Demo)",
      "category": "Отчётность",
      "year": 2024,
      "quarter": "FY",
      "url": "https://example.com/annual-2024.pdf"
    },
    {
      "title": "Презентация для LP — Стратегия 2026 (Demo)",
      "category": "Презентации",
      "year": 2025,
      "quarter": null,
      "url": "https://example.com/strategy-2026.pdf"
    },
    {
      "title": "Протокол собрания LP (Demo)",
      "category": "Протоколы",
      "year": 2025,
      "quarter": "Q1",
      "url": "https://example.com/minutes-Q1-2025.pdf"
    }
  ],
  "news": [
    {
      "date": "2025-09-10",
      "text": "Публикация демо‑обновления по портфелю. Это пример новости IR."
    },
    {
      "date": "2025-06-30",
      "text": "Релиз демо‑годового отчёта за 2024 год."
    }
  ]
};