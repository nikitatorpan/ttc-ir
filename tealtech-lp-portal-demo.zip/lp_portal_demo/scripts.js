
(function(){
  // Populate filters
  const yearSel = document.getElementById('yearFilter');
  const catSel = document.getElementById('catFilter');
  const search = document.getElementById('search');
  const docsEl = document.getElementById('docs');

  const years = Array.from(new Set(CONFIG.docs.map(d=>d.year))).sort((a,b)=>b-a);
  years.forEach(y=>{
    const o=document.createElement('option'); o.value=y; o.textContent=y; yearSel.appendChild(o);
  });
  const cats = Array.from(new Set(CONFIG.docs.map(d=>d.category))).sort();
  cats.forEach(c=>{
    const o=document.createElement('option'); o.value=c; o.textContent=c; catSel.appendChild(o);
  });

  function render(){
    const y = yearSel.value;
    const c = catSel.value;
    const q = (search.value||'').toLowerCase();

    const filtered = CONFIG.docs.filter(d=>(!y||d.year==y)&&(!c||d.category===c)&&(!q||d.title.toLowerCase().includes(q)));
    docsEl.innerHTML='';
    filtered.forEach(d=>{
      const item=document.createElement('div'); item.className='cardItem';
      const title=document.createElement('div'); title.className='title'; title.textContent=d.title; item.appendChild(title);
      const badges=document.createElement('div'); badges.className='badges';
      const b1=document.createElement('span'); b1.className='badge'; b1.textContent=d.category; badges.appendChild(b1);
      const b2=document.createElement('span'); b2.className='badge'; b2.textContent=d.year; badges.appendChild(b2);
      if(d.quarter){ const b3=document.createElement('span'); b3.className='badge'; b3.textContent=d.quarter; badges.appendChild(b3); }
      item.appendChild(badges);

      const actions=document.createElement('div'); actions.className='actions';
      const a=document.createElement('a'); a.className='button'; a.href=d.url; a.target='_blank'; a.rel='noopener'; a.textContent='Открыть';
      actions.appendChild(a);

      const copy=document.createElement('button'); copy.className='button'; copy.type='button'; copy.textContent='Копировать ссылку';
      copy.addEventListener('click', async ()=>{
        try { await navigator.clipboard.writeText(d.url); copy.textContent='Скопировано!'; setTimeout(()=>copy.textContent='Копировать ссылку', 1500); }
        catch(e){ alert('Не удалось скопировать: ' + e); }
      });
      actions.appendChild(copy);
      item.appendChild(actions);
      docsEl.appendChild(item);
    });
  }

  yearSel.addEventListener('change', render);
  catSel.addEventListener('change', render);
  search.addEventListener('input', render);

  // news
  const newsEl = document.getElementById('news');
  CONFIG.news.forEach(n=>{
    const li=document.createElement('li');
    li.innerHTML = '<strong>'+n.date+'</strong> — ' + n.text;
    newsEl.appendChild(li);
  });

  render();
})();
